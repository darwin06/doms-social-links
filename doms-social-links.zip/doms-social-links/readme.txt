
==DOMS Social Links==
Tags: social, links, shortcode
Donate link: https://www.paypal.me/darwin06
Requires at least: 4.5
Tested up to: 4.9.1
Requires PHP: 5.6
Stable tag: stable
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Shortcode Social links

== Description ==
Basic shortcode to share Social links

== Installation ==
- Goto **Plugins** select click **Add new**
- Select the plugin file **doms-social-links.zip**
- Click **Install Now**
- Into **POST**, **PAGE** or **HTML WIDGET** add: 
`[doms_social_links title="Your Title" desc="Your description info." custom="https://www.custom-url.com/" tw="twitter_user" fb="facebook_user" yt="channel/youtube_channel" in="instagram_user"]`  
each parameter is optional, just add the link/s you want to display, if you dont have *title* or *desc* just remove the parameter
- Save the **POST**, **PAGE** or **HTML WIDGET**
- Done. 


== Frequently Asked Questions ==
-- Any Question 
Please send me a email to ethan06@gmail.com

== Screenshots ==
1. View
2. Settings

== Changelog ==
Version 0.0.1
Initial Release. 