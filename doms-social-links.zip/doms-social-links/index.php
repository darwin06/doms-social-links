<?php   
// Silence is goldes
?>